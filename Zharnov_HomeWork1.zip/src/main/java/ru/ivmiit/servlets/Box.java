package ru.ivmiit.servlets;

public interface Box {
	double getWeight();
}